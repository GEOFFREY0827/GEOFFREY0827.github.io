# -*- coding: utf-8 -*-
"""
Created on Wed Jul  3 16:58:23 2024

@author: yanghaoran
"""

#定义一棵平衡树树的节点结构体（节点包括Value、leftchild、rightchild、height【用来判断平衡】）
class AVLNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None
        self.height = 1

#定义插入操作和平衡操作
#此处为递归结构，root.left/root.right在递归过程中会自动更新不需要手动更新；因此在平衡判断时直接调用root.
def insert(root,val):

    #核心插入命令（递归结构）
    #**只有当root为空时root.right为空，此时插入new_node到树的最叶节点，其余时刻处于递归状态。
    #由于采用递归写法，需要在生成平衡二叉树之前先生成一颗空树。
    if root is None:
        return AVLNode(val)    
    if val < root.val:
        root.left = insert(root.left, val)
    elif  val > root.val:
        root.right = insert(root.right,val)

#查找平衡因子并且对于失衡的二叉平衡树进行旋转以保持平衡
#此处需要调用四个函数：
#（1）找到树的高度的辅助函数get_height(node)）
#（2）对树是否平衡进行计算以确定是否需要进行旋转操作
#（3）对LL不平衡树进行右旋操作（如果root的第一级左子树拥有右子树则+一次其右子树的插入到root的左子树的操作）
#（4）对LR不平衡树的左子树进行左旋操作，后对root这个树进行右旋操作
#（5）对RR不平衡树进行左旋操作（如果root的第一级右子树拥有左子树则+一次其左子树的插入到root的右子树的操作）
#（6）对RL不平衡树的左子树进行右旋操作，后对root这个树进行左旋操作
    
    #平衡判断
    root.height = 1 + max(get_height(root.left),get_height(root.right))
    balance = get_balance(root)

    # 左旋RR
    if balance > 1 and val < root.left.val:
        return right_tran(root)
    # 右旋LL
    if balance < -1 and val > root.right.val:
        return left_tran(root)
    # 左右双旋LR
    if balance > 1 and val > root.left.val:
        root.left = left_tran(root.left)
        return right_tran(root)
    # 右左双旋RL
    if balance < -1 and val < root.right.val:
        root.right = right_tran(root.right)
        return left_tran(root)

    return root

#此处定义的get_height是非递归操作，因此节点的height在插入是也要动态调整
def get_height(node):
    if node is None:
        return 0;
    return node.height

def get_balance(node):
    if node is None:
        return 0;
    return get_height(node.left)-get_height(node.right)

#在旋转后也要更新树的height，不需要对原height进行操作（也可以，就是+1、-1而已），只需在旋转后继续调用get_height即可
#具体左旋右旋操作如上（3）（5）所述
def left_tran(node):
    R_Node = node.right
    Tran_Node = R_Node.left
    
    R_Node.left = node
    node.right = Tran_Node
    
    #更新节点高度
    
    node.height = 1 + max(get_height(node.left),get_height(node.right))
    R_Node.height = 1 + max(get_height(R_Node.left),get_height(R_Node.right))
    
    return R_Node

def right_tran(node):
    L_Node = node.left
    Tran_Node = L_Node.right
    
    L_Node.right = node
    node.left = Tran_Node
    
    #更新节点高度
    
    node.height = 1 + max(get_height(node.left),get_height(node.right))
    L_Node.height =1 + max(get_height(L_Node.left),get_height(L_Node.right))

    return L_Node






