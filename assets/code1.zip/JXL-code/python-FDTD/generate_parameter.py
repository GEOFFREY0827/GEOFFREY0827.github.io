import random
import numpy as np
import pandas as pd

epoches = 3
structure_parameters =  [[0]*1]*(epoches**5)
t = 0
data_scale = 1000

#生成随机机构参数
for i in range(data_scale):
    c = random.uniform(0.2,2)
    l = random.uniform(0.8,3.2)
    w = random.uniform(0.2,1)
    d = random.uniform(0.4,2)
    b = random.uniform(0.4,2)
    #将结构参数保存到列表当中
    structure_parameters[t] = [c,l,w,d,b]
#在矩阵第一行插入一个标题行

# 定义新的绝对路径(存有结构参数struc1000.csv的路径)
save_path = 'E:\Schottky_result_CSV/'

# 将数据转换为DataFrame
# Title = ["c","l","w","d","b","T_x","T_y"]
Title = ["c","l","w","d","b"]
df_result = pd.DataFrame(structure_parameters,columns = Title)

# 保存结果DataFrame到CSV文件
# 使用唯一标识符命名结果文件
result_filename = f'{save_path}structure_parameters.csv'
df_result.to_csv(result_filename, index=False)

#生成结构参数列表
# for i in range(epoches):
#     c = round(0.15+(i%epoches)*0.1,2)
#     for j in range(epoches):
#         l = round(0.6+(j%epoches)*0.5,2)
#         for k in range(epoches):
#             w = round(0.3+(k%epoches)*0.2,2)
#             for m in range(epoches):
#                 d = round(0.6+(m%epoches)*0.4,2)
#                 for n in range(epoches):
#                     b = round(0.6+(n%epoches)*0.4,2)
#                     structure_parameters[t] = [c,l,w,d,b]
#                     t+= 1