import os
import ctypes
import numpy as np
import pandas as pd
from absorptivity import *

# 设置 'interopapi.dll' 文件的路径
lumerical_path = 'C:\Program Files\Lumerical/v241/api\python'
interopapi_path = os.path.join(lumerical_path, 'interopapi.dll')

# 手动加载 'interopapi.dll'
try:
    lumapi = ctypes.CDLL(interopapi_path)
except Exception as e:
    print(f"Error: {e}")
    raise SystemExit

# 导入Lumerical的Python API模块
import sys
sys.path.append('C:\Program Files\Lumerical/v241/api\python')
import lumapi

# 设置FDTD工作目录和文件名
file_path = "E:\FDTD_Simulation"
file_name = "Al-W-Co-Si-1.fsp"

# 定义新的绝对路径(存有结构参数struc1000.csv的路径)
save_path = 'E:\Schottky_result_CSV/'

# 定义结构参数文件名的前缀和文件数量
prefix = "structure_parameters"
#num_files = 5  \\？为啥有这一句

# 定义结构参数文件名
csv_filename = f'{save_path}{prefix}.csv'

# 读取CSV文件，并假设文件包含c、l、w、d、b等结构参数
df_params = pd.read_csv(csv_filename)

#定义所仿数据轮数为epoches
epoches = 100
t = 0

with lumapi.FDTD() as fdtd:
    fdtd.cd(file_path)
    fdtd.load(file_name)

    fdtd.switchtolayout()
    #先做一次参数初始化生成所需的结构体
    c = 0.2 * 1e-6  # 转换为微米
    l = 0.8 * 1e-6  # 转换为微米
    w = 0.2* 1e-6  # 转换为微米
    d = 0.4 * 1e-6  # 转换为微米
    b = 0.4 * 1e-6  # 转换为微米
    T_x = 5
    T_y = 5
    x_span = T_x*(l+b)
    y_span = T_y*(d+w)
    x0 = 6.759*1e-6
    y0 = 31.097*1e-6

     #材料表里面没有找到Co，选择在FDTD里面建立一个模型用setname的方法来替代
    # structure_name = f'Co'
    # # 设置结构
    # fdtd.addrect()
    # fdtd.set('name', structure_name)
    # fdtd.set('x min', Co_Si_FDTD_X_min)
    # fdtd.set('x max', Co_Si_FDTD_X_max)
    # fdtd.set('y min', Co_Si_FDTD_Y_min)
    # fdtd.set('y max', Co_Si_FDTD_Y_max)
    # fdtd.set('z min', -0.67)
    # fdtd.set('z max', -0.65)
    # fdtd.set('material', 'Co (Cobalt)')  # 设置材料为 Co
    # 设置 W_1 的 x 和 y 坐标，基于图片中的公式
    Co_Si_FDTD_X_min = x0-(T_x//2+(T_x%2))*(l+b)
    Co_Si_FDTD_X_max = x0+(T_x//2+(T_x%2)-1)*(l+b)
    Co_Si_FDTD_Y_min = y0-(T_y//2+(T_y%2)-1)*(d+w)
    Co_Si_FDTD_Y_max = y0+(T_y//2+(T_y%2))*(d+w)

    fdtd.setnamed("Co", "x min", Co_Si_FDTD_X_min)
    fdtd.setnamed("Co", "x max", Co_Si_FDTD_X_max)
    fdtd.setnamed("Co", "y min", Co_Si_FDTD_Y_min)
    fdtd.setnamed("Co", "y max", Co_Si_FDTD_Y_max)
    fdtd.setnamed("Co", "z min", -0.67*1e-6)
    fdtd.setnamed("Co", "z max", -0.65*1e-6)
    
    structure_name = f'Si'
    # 设置结构
    fdtd.addrect()
    fdtd.set('name', structure_name)
    fdtd.set('x min', Co_Si_FDTD_X_min)
    fdtd.set('x max', Co_Si_FDTD_X_max)
    fdtd.set('y min', Co_Si_FDTD_Y_min)
    fdtd.set('y max', Co_Si_FDTD_Y_max)
    fdtd.set('z min', -3*1e-6)
    fdtd.set('z max', -0.67*1e-6)
    fdtd.set('material', 'Si (Silicon) - Palik')  # 设置材料为 Si
    for i in range(5):
        for j in range(5):
            Al_W_1_X_min = x0-c-(T_x//2+(T_x%2)/2-i)*(l+b)
            Al_W_1_X_max = x0+c-(T_x//2+(T_x%2)/2-i)*(l+b)
            Al_W_1_Y_min = y0-(w/2 + d/2)+(T_y//2+(T_y%2)/2-j)*(d+w)
            Al_W_1_Y_max = y0+(w/2 + d/2)+(T_y//2+(T_y%2)/2-j)*(d+w)

            Al_W_2_X_min = x0-l/2-(T_x//2+(T_x%2)/2-i)*(l+b)
            Al_W_2_X_max = x0+l/2-(T_x//2+(T_x%2)/2-i)*(l+b)
            Al_W_2_Y_min = y0-w/2+(T_y//2+(T_y%2)/2-j)*(d+w)
            Al_W_2_Y_max = y0+w/2+(T_y//2+(T_y%2)/2-j)*(d+w)

            # 计算结构的名称
            structure_name = f'Al_{i}_{j}_1'
            # 设置结构
            fdtd.addrect()
            fdtd.set('name', structure_name)
            fdtd.set('x min', Al_W_1_X_min)
            fdtd.set('x max', Al_W_1_X_max)
            fdtd.set('y min', Al_W_1_Y_min)
            fdtd.set('y max', Al_W_1_Y_max)
            fdtd.set('z min', 0)
            fdtd.set('z max', 0.465*1e-6)
            fdtd.set('material', 'Al (Aluminium) - CRC')  # 设置材料为 Al
            
            structure_name = f'Al_{i}_{j}_2'
            # 设置结构
            fdtd.addrect()
            fdtd.set('name', structure_name)
            fdtd.set('x min', Al_W_2_X_min)
            fdtd.set('x max', Al_W_2_X_max)
            fdtd.set('y min', Al_W_2_Y_min)
            fdtd.set('y max', Al_W_2_Y_max)
            fdtd.set('z min', 0)
            fdtd.set('z max', 0.465*1e-6)
            fdtd.set('material', 'Al (Aluminium) - CRC')  # 设置材料为 Al
            
            structure_name = f'W_{i}_{j}_1'
            # 设置结构
            fdtd.addrect()
            fdtd.set('name', structure_name)
            fdtd.set('x min', Al_W_1_X_min)
            fdtd.set('x max', Al_W_1_X_max)
            fdtd.set('y min', Al_W_1_Y_min)
            fdtd.set('y max', Al_W_1_Y_max)
            fdtd.set('z min', -0.65*1e-6)
            fdtd.set('z max', 0)
            fdtd.set('material', 'W (Tungsten) - Palik')  # 设置材料为 W
            
            structure_name = f'W_{i}_{j}_2'
            # 设置结构
            fdtd.addrect()
            fdtd.set('name', structure_name)
            fdtd.set('x min', Al_W_2_X_min)
            fdtd.set('x max', Al_W_2_X_max)
            fdtd.set('y min', Al_W_2_Y_min)
            fdtd.set('y max', Al_W_2_Y_max)
            fdtd.set('z min', -0.65*1e-6)
            fdtd.set('z max', 0)
            fdtd.set('material', 'W (Tungsten) - Palik')  # 设置材料为 W
            
            # #材料表里面没有找到Co，选择在FDTD里面建立一个模型用setname的方法来替代
            # # structure_name = f'Co'
            # # # 设置结构
            # # fdtd.addrect()
            # # fdtd.set('name', structure_name)
            # # fdtd.set('x min', Co_Si_FDTD_X_min)
            # # fdtd.set('x max', Co_Si_FDTD_X_max)
            # # fdtd.set('y min', Co_Si_FDTD_Y_min)
            # # fdtd.set('y max', Co_Si_FDTD_Y_max)
            # # fdtd.set('z min', -0.67)
            # # fdtd.set('z max', -0.65)
            # # fdtd.set('material', 'Co (Cobalt)')  # 设置材料为 Co
            # # 设置 W_1 的 x 和 y 坐标，基于图片中的公式
            # fdtd.setnamed("Co", "x min", Co_Si_FDTD_X_min)
            # fdtd.setnamed("Co", "x max", Co_Si_FDTD_X_max)
            # fdtd.setnamed("Co", "y min", Co_Si_FDTD_Y_min)
            # fdtd.setnamed("Co", "y max", Co_Si_FDTD_Y_max)
            # fdtd.setnamed("Co", "z min", -0.67*1e-6)
            # fdtd.setnamed("Co", "z max", -0.65*1e-6)
            
            # structure_name = f'Si'
            # # 设置结构
            # fdtd.addrect()
            # fdtd.set('name', structure_name)
            # fdtd.set('x min', Co_Si_FDTD_X_min)
            # fdtd.set('x max', Co_Si_FDTD_X_max)
            # fdtd.set('y min', Co_Si_FDTD_Y_min)
            # fdtd.set('y max', Co_Si_FDTD_Y_max)
            # fdtd.set('z min', -3*1e-6)
            # fdtd.set('z max', -0.67*1e-6)
            # fdtd.set('material', 'Si (Silicon) - Palik')  # 设置材料为 Si

            # 设置 FDTD 的 x 和 y 坐标
            fdtd.setnamed("FDTD", "x min", -(T_x//2+(T_x%2)/2)*(l+b))
            fdtd.setnamed("FDTD", "x max", (T_x//2+(T_x%2)/2)*(l+b))
            fdtd.setnamed("FDTD", "y min", -(T_y//2+(T_y%2)/2)*(d+w))
            fdtd.setnamed("FDTD", "y max", (T_y//2+(T_y%2)/2)*(d+w))

            # 设置 trans_box 的 x span 和 y span
            fdtd.setnamed("trans_box", "x span", x_span)
            fdtd.setnamed("trans_box", "y span", y_span)

     # 关闭FDTD仿真会话
    fdtd.save()
    fdtd.close()
    
    
    


