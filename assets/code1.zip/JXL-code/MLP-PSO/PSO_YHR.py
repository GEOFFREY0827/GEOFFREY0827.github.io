import numpy as np
import torch
import pandas as pd
from MLP_YHR import MLP
from particle_initial import *
from Cal_PSO_Absorptivity import cal_ave_absorp_PSO
import matplotlib.pyplot as plt
# # 验证函数
# def verify(particles):
#     for i in range(len(particles)):
#         if particles[4] < particles[0] or particles[4] > particles[1]:
#             return False
#         if particles[0] < particles[3]:
#             return False
#         if particles[2] < particles[1]:
#             return False
#         if particles[2] < particles[3]:
#             return False
#         if particles[4] is particles[0] or particles[4] is particles[1]:
#             return False
#         if particles[0] is particles[3]:
#             return False
#         if particles[2] is particles[1]:
#             return False
#         if particles[2] is particles[3]:
#             return False
#     return True
# 加载模型并加载权重
def load_model(weights_path):
    model = MLP()
    model.load_state_dict(torch.load(weights_path, map_location=torch.device('cpu'), weights_only=True))
    model.eval()
    return model


# 读取并标准化输入数据
def standardize_input(input_data, scaler_params):
    scaler_params = scaler_params.astype(np.float32)  # 转换为float32类型
    mean = scaler_params['mean'].values
    std = scaler_params['std'].values
    standardized_data = (input_data - mean) / std
    return standardized_data


# 目标函数：计算神经网络输出的三个参数之和
def objective_function(input_params, model, scaler_params):
    # 将粒子的位置（10个参数）转化为输入数据的格式
    input_data = torch.tensor(input_params, dtype=torch.float32).unsqueeze(0)  # 确保是float32类型

    # 标准化输入数据
    standardized_data = standardize_input(input_data, scaler_params)

    # 使用神经网络进行预测
    with torch.no_grad():
        predictions = model(standardized_data).numpy()

    # 目标函数是300个输出参数的和
    output_sum = cal_ave_absorp_PSO(predictions,2000,2500)
    return output_sum


# 粒子群优化（PSO）算法
def pso(num_particles, num_iterations, model, scaler_params, bounds,bounds_real):
    # 初始化粒子位置和速度
    
    particles = particle_generate(bounds,num_particles).astype(np.float32)  # 粒子位置（5个待优化参数）
    
    velocities = np.zeros_like(particles)  # 粒子速度
    personal_best_positions = particles.copy()  # 粒子个人最佳位置
    
    personal_best_scores = np.array([objective_function(p, model, scaler_params) for p in particles_decode(particles,num_particles)])  # 粒子个人最佳得分
  
    global_best_position = personal_best_positions[np.argmax(personal_best_scores)]  # 全局最佳位置
    global_best_score = np.max(personal_best_scores)  # 全局最佳得分

    # PSO参数
    inertia_weight_initial = 0.9  # 惯性权重
    cognitive_weight_initial = 1.5  # 认知权重
    social_weight_initial = 1.5  # 社会权重
    inertia_weight_end = 0.4  # 惯性权重
    cognitive_weight_end = 0.5  # 认知权重
    social_weight_end = 0.5  # 社会权重
    j = 0
    best_score_array = np.array([])
    # 迭代更新粒子的位置和速度
    for iteration in range(num_iterations):
        inertia_weight = inertia_weight_initial- (inertia_weight_initial- inertia_weight_end)*((iteration/num_iterations)**2)# 变化惯性权重
        cognitive_weight = cognitive_weight_initial- (cognitive_weight_initial- cognitive_weight_end)*((iteration/num_iterations)**2)  # 变化认知权重
        social_weight = social_weight_initial- (social_weight_initial- social_weight_end)*((iteration/num_iterations)**2) #变哈社会权重
        for i in range(num_particles):
            # 更新速度
            r1, r2 = np.random.rand(2)  # 随机数
            velocities[i] = (inertia_weight * velocities[i] +
                             cognitive_weight * r1 * (personal_best_positions[i] - particles[i]) +
                             social_weight * r2 * (global_best_position - particles[i]))

            # 更新位置
            particles[i] += velocities[i]

            # 保证粒子位置在给定的范围内
            particles[i] = np.clip(particles[i], bounds[:, 0], bounds[:, 1])

            # 计算当前粒子的目标函数值
            current_score = objective_function(particle_decode(particles[i]), model, scaler_params)
            
            # 更新个人最佳
            if current_score > personal_best_scores[i]:
                personal_best_positions[i] = particles[i].copy()
                personal_best_scores[i] = current_score
            
        # 更新全局最佳
        current_global_best_score = np.max(personal_best_scores)
        if current_global_best_score > global_best_score:
            global_best_score = current_global_best_score
            global_best_position = personal_best_positions[np.argmax(personal_best_scores)]
        
        best_score_array = np.append(best_score_array,global_best_score)
        # 打印当前最好的结果
        print(f"Iteration {iteration + 1}/{num_iterations}, Best Score: {global_best_score}")

    return global_best_position, global_best_score, best_score_array
# 主函数
def main():
    # 设置文件路径
    weights_path = r'D:\AI_Medical/MLP_Schottky/best_model.pth'  # 已保存的模型权重文件路径
    scaler_params_path = r'D:\AI_Medical/MLP_Schottky/scaler_mean_std.csv'  # 标准化参数文件路径

    # 加载模型和标准化参数
    model = load_model(weights_path)
    scaler_params = pd.read_csv(scaler_params_path)
    
    # PSO算法的参数
    num_particles = 30  # 粒子数量
    num_iterations = 50  # 迭代次数
    # 每个参数的取值范围（假设每个参数的范围不同）
    bounds_real = np.array([
    [0.2, 6.0],   # 参数1的范围
    [0.2, 5.0],   # 参数2的范围
    [0.3, 6.0],   # 参数3的范围
    [0.2, 5.0],  # 参数4的范围
    [0.4, 7.0], # 参数5的范围
])
    bounds = np.array([
    [0.1, 1.0],   # 参数1的范围
    [0.2, 5.0],   # 参数2的范围
    [0.1, 1.0],   # 参数3的范围
    [0.2, 5.0],  # 参数4的范围
    [0.1, 2.0], # 参数5的范围
])
    
    # 运行PSO算法
    best_position, best_score,best_score_array = pso(num_particles, num_iterations, model, scaler_params, bounds,bounds_real)
    # 输出优化结果
    print(f"优化结束，最优参数: {particle_decode(best_position)}")
    print(f"最优目标函数值: {best_score}")
    # 创建图形
    plt.figure(figsize=(10, 6))
    x = np.arange(0, 50,1)
    # 绘制第一条数据线
    plt.plot(x, best_score_array)


    # 添加标题和标签
    plt.title('Plot of Best Score')
    plt.xlabel('X Axis Label')
    plt.ylabel('Y Axis Label')

    

    # 显示图形
    plt.show()


if __name__ == "__main__":
    main()


