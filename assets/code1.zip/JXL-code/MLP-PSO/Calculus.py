import pandas as pd
import numpy as np
import math
from scipy.integrate import trapz, simps

def Calculus(predictions):
    # 假设 x 和 y 是你的数据点
    x = np.linspace(0, 1, 3000)  # 3000个点从0到1
    y = predictions    # 示例函数 y = sin(2πx)

    # 数值微分
    # 使用中心差分计算导数
    dy_center = np.gradient(y, x)

    # 数值积分
    # # 使用梯形法则进行积分
    # integral_trapz = trapz(y, x)

    # 使用辛普森法则进行积分
    integral_simps = simps(y, x)
    return integral_simps