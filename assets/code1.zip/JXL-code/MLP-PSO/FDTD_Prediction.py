import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset
import os

# 定义具有两个隐藏层的MLP模型
class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.layer1 = nn.Linear(5, 32)  # 输入层到第一个隐藏层（5个节点 -> 32个节点）
        self.layer2 = nn.Linear(32, 16)  # 第一个隐藏层到第二个隐藏层（32个节点 -> 16个节点）
        self.layer3 = nn.Linear(16, 300)   # 第二个隐藏层到输出层（16个节点 -> 3 个节点）

    def forward(self, x):
        x = torch.relu(self.layer1(x))  # 第一个隐藏层加ReLU激活函数
        x = torch.relu(self.layer2(x))  # 第二个隐藏层加ReLU激活函数
        x = self.layer3(x)              # 输出层，通常输出层没有激活函数（根据需求可以修改）
        return x


# 创建保存文件夹
def create_output_folder(folder_name):
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    return folder_name

def load_and_preprocess_data(file_path, output_folder):
    # 读取数据
    data = pd.read_excel(file_path, engine='openpyxl')

    # 删除第一列（序号列），然后提取输入特征和目标变量
    X = data.iloc[:, 1:12].values  # 选择第2到第12列作为输入特征（9个输入）
    y = data.iloc[:, 12:15].values   # 选择第12到第15列作为输出（3个目标）

    print("X data shape:", X.shape)
    print("y data shape:", y.shape)

    # 打印输入和输出的前五行数据（标准化之前）
    print("\nFirst 5 rows of input (X) before normalization:")
    print(X[:5])  # 打印输入数据的前五行（标准化之前）

    print("\nFirst 5 rows of output (y) before normalization:")
    print(y[:5])  # 打印输出数据的前五行（标准化之前）

    # 划分训练集和测试集（避免数据泄露）
    #X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)
    train_size = int(len(X) * 0.9)
    X_train = X[:train_size]
    y_train = y[:train_size]
    X_test = X[train_size:]
    y_test = y[train_size:]
    # 打印划分后的训练集和测试集数据（标准化之前）
    print("\nFirst 5 rows of input (X) from the training set before normalization:")
    print(X_train[:5])  # 打印训练集输入数据的前五行（标准化之前）

    print("\nFirst 5 rows of input (X) from the test set before normalization:")
    print(X_test[:5])  # 打印测试集输入数据的前五行（标准化之前）

    # 数据标准化：在训练集上拟合Scaler，再对训练集和测试集分别转换
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)  # 训练集上标准化
    X_test_scaled = scaler.transform(X_test)  # 测试集上标准化（使用训练集的均值和方差）

    # 打印标准化后的数据
    print("\nFirst 5 rows of normalized input (X) from the training set:")
    print(X_train_scaled[:5])  # 打印训练集标准化后的前五行输入数据

    print("\nFirst 5 rows of normalized input (X) from the test set:")
    print(X_test_scaled[:5])  # 打印测试集标准化后的前五行输入数据

    # 将标准化前后的数据保存为CSV文件
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 保存标准化前的训练集和测试集数据
    pd.DataFrame(X_train, columns=[f'Feature_{i + 1}' for i in range(X_train.shape[1])]).to_csv(
        os.path.join(output_folder, 'X_train_before_normalization.csv'), index=False)
    pd.DataFrame(y_train, columns=['Output_1', 'Output_2', 'Output_3']).to_csv(  # 修改为3列
        os.path.join(output_folder, 'y_train_before_normalization.csv'), index=False)

    pd.DataFrame(X_test, columns=[f'Feature_{i + 1}' for i in range(X_test.shape[1])]).to_csv(
        os.path.join(output_folder, 'X_test_before_normalization.csv'), index=False)
    pd.DataFrame(y_test, columns=['Output_1', 'Output_2', 'Output_3']).to_csv(  # 修改为3列
        os.path.join(output_folder, 'y_test_before_normalization.csv'), index=False)

    # 转换为PyTorch张量
    X_train_tensor = torch.tensor(X_train_scaled, dtype=torch.float32)
    X_test_tensor = torch.tensor(X_test_scaled, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test, dtype=torch.float32)

    # 使用TensorDataset封装数据
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

    # 在训练脚本的标准化部分之后添加以下代码以保存均值和方差
    scaler_mean_std = pd.DataFrame({'mean': scaler.mean_, 'std': scaler.scale_})
    scaler_mean_std.to_csv(os.path.join(output_folder, 'scaler_mean_std.csv'), index=False)

    # 返回训练集和测试集数据
    return train_dataset, test_dataset


# 保存损失到Excel文件
def save_loss_to_excel(train_losses_output1, train_losses_output2, train_losses_output3,
                       test_losses_output1, test_losses_output2, test_losses_output3,
                       total_train_losses, total_test_losses, output_folder):
    # 将损失数据转换为DataFrame
    loss_df = pd.DataFrame({
        'Epoch': range(1, len(train_losses_output1) + 1),
        'Train Loss Output 1': train_losses_output1,
        'Train Loss Output 2': train_losses_output2,
        'Train Loss Output 3': train_losses_output3,
        'Total Train Loss': total_train_losses,
        'Test Loss Output 1': test_losses_output1,
        'Test Loss Output 2': test_losses_output2,
        'Test Loss Output 3': test_losses_output3,
        'Total Test Loss': total_test_losses
    })

    # 保存到Excel文件
    loss_file = os.path.join(output_folder, 'training_losses.xlsx')
    loss_df.to_excel(loss_file, index=False)


# 主训练过程
def train_model(train_dataset, test_dataset, output_folder, batch_size=32, epochs=2000):
    model = MLP()  # 假设模型为MLP

    # 定义损失函数和优化器
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    # 创建DataLoader对象
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    # 存储损失
    train_losses_output1 = []
    train_losses_output2 = []
    train_losses_output3 = []
    test_losses_output1 = []
    test_losses_output2 = []
    test_losses_output3 = []
    total_train_losses = []
    total_test_losses = []

    # 初始化最优损失和最优权重
    best_test_loss = float('inf')  # 最初设置为无穷大
    best_model_weights = None
    
    # 确保输出文件夹存在
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 训练
    for epoch in range(epochs):
        model.train()
        running_loss_output1 = 0.0
        running_loss_output2 = 0.0
        running_loss_output3 = 0.0
        total_train_loss = 0.0

        # 遍历训练集
        for inputs, targets in train_loader:
            optimizer.zero_grad()
            outputs = model(inputs)

            # 计算每个输出的损失
            output1_loss = criterion(outputs[:, 0], targets[:, 0])  # 第一输出的损失
            output2_loss = criterion(outputs[:, 1], targets[:, 1])  # 第二输出的损失
            output3_loss = criterion(outputs[:, 2], targets[:, 2])  # 第三输出的损失
            total_loss = output1_loss + output2_loss + output3_loss  # 总损失

            # 反向传播
            total_loss.backward()
            optimizer.step()

            # 记录损失
            running_loss_output1 += output1_loss.item()
            running_loss_output2 += output2_loss.item()
            running_loss_output3 += output3_loss.item()
            total_train_loss += total_loss.item()

        # 计算每个epoch的训练损失
        avg_train_loss_output1 = running_loss_output1 / len(train_loader)
        avg_train_loss_output2 = running_loss_output2 / len(train_loader)
        avg_train_loss_output3 = running_loss_output3 / len(train_loader)
        avg_total_train_loss = total_train_loss / len(train_loader)

        train_losses_output1.append(avg_train_loss_output1)
        train_losses_output2.append(avg_train_loss_output2)
        train_losses_output3.append(avg_train_loss_output3)
        total_train_losses.append(avg_total_train_loss)

        # 计算测试集损失
        model.eval()
        running_test_loss_output1 = 0.0
        running_test_loss_output2 = 0.0
        running_test_loss_output3 = 0.0
        total_test_loss = 0.0

        with torch.no_grad():
            for inputs, targets in test_loader:
                outputs = model(inputs)
                output1_loss = criterion(outputs[:, 0], targets[:, 0])
                output2_loss = criterion(outputs[:, 1], targets[:, 1])
                output3_loss = criterion(outputs[:, 2], targets[:, 2])
                total_loss = output1_loss + output2_loss + output3_loss

                running_test_loss_output1 += output1_loss.item()
                running_test_loss_output2 += output2_loss.item()
                running_test_loss_output3 += output3_loss.item()
                total_test_loss += total_loss.item()

        avg_test_loss_output1 = running_test_loss_output1 / len(test_loader)
        avg_test_loss_output2 = running_test_loss_output2 / len(test_loader)
        avg_test_loss_output3 = running_test_loss_output3 / len(test_loader)
        avg_total_test_loss = total_test_loss / len(test_loader)

        test_losses_output1.append(avg_test_loss_output1)
        test_losses_output2.append(avg_test_loss_output2)
        test_losses_output3.append(avg_test_loss_output3)
        total_test_losses.append(avg_total_test_loss)

        # 每个epoch输出损失
        print(
            f'Epoch [{epoch + 1}/{epochs}], '
            f'Train Loss Output 1: {avg_train_loss_output1:.4f}, '
            f'Train Loss Output 2: {avg_train_loss_output2:.4f}, '
            f'Train Loss Output 3: {avg_train_loss_output3:.4f}, '
            f'Total Train Loss: {avg_total_train_loss:.4f}, '
            f'Test Loss Output 1: {avg_test_loss_output1:.4f}, '
            f'Test Loss Output 2: {avg_test_loss_output2:.4f}, '
            f'Test Loss Output 3: {avg_test_loss_output3:.4f}, '
            f'Total Test Loss: {avg_total_test_loss:.4f}'
        )

        # 如果当前epoch的测试损失更小，则保存最优模型权重
        if avg_total_test_loss < best_test_loss:
            best_test_loss = avg_total_test_loss
            best_model_weights = model.state_dict()  # 保存当前最优模型的权重

            # 保存最优模型的权重
            torch.save(best_model_weights, os.path.join(output_folder, 'best_model.pth'))

        # 保存最终模型的权重
    torch.save(model.state_dict(), os.path.join(output_folder, 'final_model.pth'))

    # 保存损失
    save_loss_to_excel(
        train_losses_output1, train_losses_output2, train_losses_output3,
        test_losses_output1, test_losses_output2, test_losses_output3,
        total_train_losses, total_test_losses, output_folder
    )

    return model


# 主函数
def main():
    # 设置文件路径
    input_file = r'D:\Desktop\xue_LDMOS\dataset_11.xlsx'  # 请根据实际文件路径修改

    # 读取 Excel 文件并指定 engine
    data = pd.read_excel(input_file, engine='openpyxl')

    print(data.head())  # 查看数据内容，确保数据加载正确

    # 创建输出文件夹
    output_folder = create_output_folder('MLP1_5')

    # 加载并预处理数据
    train_dataset, test_dataset = load_and_preprocess_data(input_file, output_folder)

    # 训练模型
    train_model(train_dataset, test_dataset, output_folder)


if __name__ == '__main__':
    main()