import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

file_path = r'D:\AI_Medical/MLP_Schottky/training_losses.xlsx'
data = pd.read_excel(file_path, engine='openpyxl')
data.to_csv("D:\AI_Medical/MLP_Schottky/training_losses.csv", index=False)
file_path = r'D:\AI_Medical/MLP_Schottky/training_losses.csv'
data = pd.read_csv(file_path)
x = data.iloc[:, 0]
y1 = data.iloc[:, 1]
y2 = data.iloc[:, 2]

# 创建图形
plt.figure(figsize=(10, 6))

# 绘制第一条数据线
plt.plot(x, y1, label='Data Line 1')

# 绘制第二条数据线
plt.plot(x, y2, label='Data Line 2')

# 添加标题和标签
plt.title('Plot of Multiple Data Lines from CSV')
plt.xlabel('X Axis Label')
plt.ylabel('Y Axis Label')

# 添加图例
plt.legend()

# 显示图形
plt.show()
