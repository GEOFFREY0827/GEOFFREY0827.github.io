
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d, lagrange, Rbf
from scipy.interpolate import CubicSpline
import warnings


def interpid(predictions):
    # 生成数据
    x = []
    for i in range(300):
        x.append(i)
    x = np.array(x)
    y = predictions[0]

    # # 线性插值
    # f_linear = interp1d(x, y, kind='linear')
    
    # 拉格朗日插值
    f_lagrange = lagrange(x, y)
    
    # # 样条插值
    # f_spline = CubicSpline(x, y)
    
    # # 径向基函数插值
    # f_rbf = Rbf(x, y, function='gaussian')
    
    # 生成插值点
    x_new = np.linspace(x.min(), x.max(), 3000)
    
    # 计算插值结果
    # y_linear = f_linear(x_new)
    y_lagrange = f_lagrange(x_new)
    # y_spline = f_spline(x_new)
    # y_rbf = f_rbf(x_new)
    return y_lagrange
    # plt.figure(figsize=(10, 6))
    # plt.plot(x, y, 'o', label='Data Points')
    # # plt.plot(x_new, y_linear, label='Linear Interpolation')
    # plt.plot(x_new, y_lagrange, label='Lagrange Interpolation')
    # # plt.plot(x_new, y_spline, label='Cubic Spline Interpolation')
    # # plt.plot(x_new, y_rbf, label='RBF Interpolation')
    # plt.legend()
    # # plt.title('Comparison of Different Interpolation Methods')
    # plt.xlabel('x')
    # plt.ylabel('y')
    # plt.show()


# def interpid(predictions):
#     # 生成数据
#     x = np.arange(300)
#     y = predictions[0]


#     # 确保 y 的长度至少为 2
#     if len(y) < 2:
#         raise ValueError("predictions must have at least two elements for interpolation.")

#     # 自定义拉格朗日插值
#     f_lagrange = lagrange_interpolation(x, y, np.linspace(x.min(), x.max(), 3000))
    
#     # 计算插值结果
#     y_lagrange = f_lagrange
    
#     return y_lagrange