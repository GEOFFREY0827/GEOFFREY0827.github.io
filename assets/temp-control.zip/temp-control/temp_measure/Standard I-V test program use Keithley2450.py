# -*- coding: utf-8 -*-
"""
Created on Tue Oct 11 15:14:58 2022

@author: LIUZHEN
Standard I-V test program use Keithley2450_SCPI
The method to install pymeasure:http://114.212.112.60/gpblog/2022/09/%e5%88%a9%e7%94%a8%e5%bc%80%e6%ba%90pymeasure%e5%bf%ab%e9%80%9f%e7%bc%96%e5%86%99%e4%bb%aa%e5%99%a8%e9%a9%b1%e5%8a%a8%e7%a8%8b%e5%ba%8f%e6%96%b9%e6%b3%95/
"""
import pyvisa as visa
import os
import sys

import numpy as np
import time 
import datetime
from matplotlib import pyplot as plt
from scipy.optimize import fmin
import scipy.io
import scipy.io as sio

from pymeasure.instruments.keithley import Keithley2450
keithley = Keithley2450("USB0::0x05E6::0x2450::04595034::0::INSTR") # keithley2450地址
keithley.reset() #keithley2450初始化
time.sleep(0.1)

#=================================================================================================
#初始需修改的参数

#sample_number = '20231030_'   # 样品批号
Test_port     = '1-1'          # 测试口编号
Temperature  =  '1.62'
# Device_no     = '1'           # 器件pad编号

V_max  = 1.2# IV扫描最大电压，单位：V 
V_step = 0.005 # 电压步进
R_bias = 22000  # 偏置电阻大小

#=================================================================================================

I = [] # 电流  
V = [] # 电压
 
V_set = [0]     # 实时设定电压
V_add = 0       # 设定电压的初始值

#=================================================================================================
# 获取扫描电压列表 
for i in range(4*int(V_max/V_step)):
    if (i<int(V_max/V_step)):
        V_add = V_add+V_step
        V_set.append(V_add)
    elif (i<2*int(V_max/V_step)):
        V_add = V_add-V_step
        V_set.append(V_add)
    elif (i<3*int(V_max/V_step)):
        V_add = V_add-V_step
        V_set.append(V_add)
    elif (i<4*int(V_max/V_step)):
        V_add = V_add+V_step
        V_set.append(V_add)
# print(V_set) # 用来检查设定电压列表是否正确  

#==================================================================================================
# 测量部分

keithley.use_rear_terminals             #使用仪器前面端子
keithley.wires
keithley.apply_voltage()                # Sets up to source voltage
keithley.compliance_current = 0.1       # Sets the compliance current
keithley.auto_range_source()
keithley.measure_current()              # Sets up to measure current

keithley.enable_source()                #打开源表
time.sleep(0.1)

for i in range(len(V_set)):
    keithley.source_voltage = V_set[i]
    time.sleep(0.1)
    current = keithley.current
    I.append(current)
    V.append(V_set[i]-current*R_bias)    
    print('此时的电流为=',current,'此时的电压为=',V_set[i],'此时的器件上电压为=',V_set[i]-current*R_bias)
    # plt.plot(V, I, 'b.')
    # plt.grid(True)
    # plt.xlabel('Voltage / V')
    # plt.ylabel('Current / uA')
    # plt.show()
    # time.sleep(0.1)
    
keithley.shutdown()                     # Ramps the current to 0 mA and disables output



#=================================================================================================================
#保存文件为matlab格式

last_time = time.time()
time_str = datetime.datetime.now().strftime('%Y-%m-%d_%H%M%S')

datapath = 'D:\\KPLZ-WSH\\test-pc\\放大器输出\\'            # 数据文件夹目录
if not os.path.exists(datapath) :
    os.makedirs (datapath)
fileName =Temperature +'_'+ Test_port +'_' +'_Vmax_' + str(V_max) +'_Vstep_'+ str(V_step)+'_R_bias_'+ str(R_bias) +'_'+ time_str+'.mat'   # 保存的数据文件名称
matFile = datapath +fileName  + '.mat'
sio.savemat(matFile, {'V_source_set' : V_set,'V': V,'I': I}) 


plt.plot(V, I, 'b.')
plt.grid(True)
plt.xlabel('Voltage / V')
plt.ylabel('Current / uA')
plt.show()