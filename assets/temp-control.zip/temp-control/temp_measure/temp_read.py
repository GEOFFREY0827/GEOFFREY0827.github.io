# -*- coding: utf-8 -*-
"""
Created on Wed May 22 20:48:22 2024

@author: yanghaoran
"""

import pyvisa
import visa
import numpy as np
from matplotlib import pyplot as plt
from scipy.optimize import fmin
import scipy.io
import os
from DP832 import *
from Instruments_communication.Model_211 import *
from temp_control.PID import *

DP832 = DP832('USB0::0x1AB1::0x0E11::DP8C245007180::0::INSTR')
m211 = Model_211('ASRL3::INSTR')

data_tem = np.array([])
data_vol = np.array([])

#
# n=0
# for i in range(100):
#   DP832.set_current('ch2',0.5)
#   DP832.set_voltage('ch2', vol_tempo)
#   vol_tempo+=0.1
#   n+=1
#   time.sleep(10)
#     #读取Model_211的温度值
for i in range(10):
    data_tem = np.append(data_tem, m211.measure_tem())
    data_vol = np.append(data_vol, DP832.measure_voltage('ch2'))
    time.sleep(1)
  # if(m211.measure_tem()>=30):
  #     break
 
#
i=0
for i in range (10):   
    print(data_tem[i],data_vol[i],sep = " & ", end = " / ") 