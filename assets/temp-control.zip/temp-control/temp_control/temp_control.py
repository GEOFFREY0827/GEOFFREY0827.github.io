# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pyvisa
import visa
import numpy as np
from matplotlib import pyplot as plt
from scipy.optimize import fmin
import scipy.io
import os
from DP832 import *
from Instruments_communication.Model_211 import *
from temp_control.PID import *

DP832 = DP832('USB0::0x1AB1::0x0E11::DP8C245007180::0::INSTR')
m211 = Model_211('ASRL3::INSTR')
pid_control = PID(9.6,7.5,16,5)
SM2450 = SM_2450('USB0::0x1AB1::0x0E11::DP8C245007180::0::INSTR')

#创建数组用于储存从Model_211读取的温度值
data_tem = np.array([])
data_vol = np.array([])
#DP832.set_current('ch1',0.5)
vol_tempo = 0
set_tem=float(input("请输入设定的温度值： "))

# #reset 代码
DP832.set_current('ch2',0.5)
DP832.set_voltage('ch2',0)


#基于model_211的P-T曲线测量
# n=0
# for i in range(100):
#   DP832.set_current('ch2',0.5)
#   DP832.set_voltage('ch2', vol_tempo)
#   vol_tempo+=0.1
#   n+=1
#   time.sleep(10)
#     #读取Model_211的温度值
#   for i in range(10):
#       data_tem = np.append(data_tem, m211.measure_tem())
#       data_vol = np.append(data_vol, DP832.measure_voltage('ch2'))
#   if(m211.measure_tem()>=30):
#       break

#基于dt_670的P-T曲线测量
# n=0
# for i in range(100):
#   DP832.set_current('ch2',0.5)
#   DP832.set_voltage('ch2', vol_tempo)
#   vol_tempo+=0.1
#   n+=1
#   time.sleep(10)
#   #对采集到的dt670的电压值进行处理获得其在温度上的投影
#   temprature = SM_2450.measure_voltage
#     #读取Model_211的温度值
#   for i in range(10):
#       data_tem = np.append(data_tem, m211.measure_tem())
#       data_vol = np.append(data_vol, DP832.measure_voltage('ch2'))
#   if(m211.measure_tem()>=30):
#       break





#PID算法控制温度
# while(1):
#     derta = set_tem-m211.measure_tem()
#     if(derta>0.01 or vol_tempo>=30):
#       DP832.set_voltage('ch1', 20)
#       DP832.set_current('ch1', 1)  
#     if(derta>0.01):
#       vol_tempo = pid_control.get_pid(derta,1)
#       DP832.set_voltage('ch1', vol_tempo)
#       DP832.set_current('ch1', 1)
#       data_tem =np.append(data_tem, m211.measure_tem())
#     if(derta<0.1):
#         DP832.set_voltage('ch1', 0)
#         DP832.set_current('ch1', 1)
      





# #用数组dataVol_matrix和dataCur_matrix分别储存从DP832读到的V和I，此处为一维数组，数据复杂时也可定义二维数据array【】，若为二维数组，用rows和cols定义数组的行和列，
# dataVol_matrix=[0 for i in range(4)]
# dataCur_matrix=[0 for i in range(4)]

# #通过一个for循环将设置的数据写入
# for i in range(4):
#     dataVol_matrix[i] = DP832.measure_voltage('ch1')
#     dataCur_matrix[i] = DP832.measure_current('ch1')





# #创建一个mat文件，便于用MATLAB绘制出具体曲线/图形
# myfilename_data = 'C:\\Users\\yanghaoran\\Desktop\\EXPERIMENT\\'+'3.20.2024'+'.mat'
# data_dict = {'Dev_Vol':datatem_array[i] }   
# scipy.io.savemat(myfilename_data, mdict=data_dict)
# i=0
# for i in range (n):   
#     print(data_tem[i],data_vol[i],sep = " & ", end = " / ") 










