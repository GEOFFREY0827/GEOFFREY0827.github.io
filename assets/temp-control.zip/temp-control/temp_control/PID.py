# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 10:22:11 2024

@author: yanghaoran
"""

from math import pi, isnan
#isnan用于检测数字是否为“nan”，若为“nan”则返回true，否则返回false。
#time库函数
import time

#此处采集得到millisecond值
#time.time()函数获得当前程序运行的时间戳
#时间戳表示的是从1970年1月1日00:00:00开始按秒计算的偏移量，*1000后可以将时间精确到亚秒级
def millis():
    return int(time.time() * 1000)
 
#定义PID算法的类为PID
class PID:
    _kp = _ki = _kd = _integrator = _imax = 0 #设置初始比例系数、积分系数、微分系数、积分量初值、积分限幅均为零
    _last_error = _last_derivative = _last_t = 0 #error为目标值-实际值，设置初始差值、微分量初值、上次一轮PID结束后的时间
    #定义一个init传参函数，便于后续调试PID算法中的不同系数
    def __init__(self, p=0, i=0, d=0, imax=0): #self指PID这个类的实例（本体）
        self._kp = float(p)
        self._ki = float(i)
        self._kd = float(d)
        self._imax = abs(imax)
        self._last_derivative = float('nan') #用nan标记不抖动的时刻
 
    #将积分值清零，以免积分值不断累加，导致PID算法失控
    def reset_I(self):
        self._integrator = 0
        self._last_derivative = float('nan')       
    
    def get_pid(self, error, scaler):
    #根据差值，K获取pid
        tnow = millis()
		#现在的时间
        dt = tnow - self._last_t
		#和上次的时间差
        output = 0
		#总输出（此处为控制加热装置的电压值）
        if self._last_t == 0 or dt > 1000:
		#如果是第一个轮回（初始值为0）或时间差>1s（大于可微积分的阈值）
            dt = 0
		#时间差归零
            self.reset_I()
			#重置I
        self._last_t = tnow
		#记录结束时间
        delta_time = float(dt) / float(1000)
		#获取Δt
        output += error * self._kp
		#加入比例控制积分
        if abs(self._kd) > 0 and dt > 0:
		#若微分参数和时间差>0
            if isnan(self._last_derivative):
		    #若微分是NaN
                derivative = 0
			#微分归零
                self._last_derivative = 0
			#nan时不抖，故不需要Derivative来进行调控
            else:
            #否则    
                derivative = (error - self._last_error) / delta_time
                #微分为：（这次的差距-上次的差距）/时间差
            self._last_error = error
			#更新差值
            self._last_derivative = derivative
			#更新积分值
            output += self._kd * derivative
			#加入微分控制
        output *= scaler
		#乘以总系数
        #PD为主要调控参数，假设没有静差，PID则在PD之间来回循环直到达到指定值，I的作用相当于在有静差的情况下开启一轮新的PD，因此选择在执行完一次PD之后更新一次error的值。
        if abs(self._ki) > 0 and dt > 0:
		#若I参数>0
            self._integrator += (error * self._ki) * scaler * delta_time
			#计算积分控制
            if self._integrator < -self._imax: self._integrator = -self._imax
			
            elif self._integrator > self._imax: self._integrator = self._imax
			#积分大于等于设定最大值时
            output += self._integrator
			#加入积分控制
        return output