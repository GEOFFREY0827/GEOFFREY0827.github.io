# -*- coding: utf-8 -*-
"""
Created on Tue Jul  2 17:21:29 2024

@author: yanghaoran
"""


import pyvisa
import visa
import numpy as np
from matplotlib import pyplot as plt
from scipy.optimize import fmin
import scipy.io as sio
import os
from DP832 import *
from Instruments_communication.Model_211 import *
from temp_control.PID import *
from Instruments_communication.SM_2400 import *
from dataset.AVL_tree import *
from SM_2450 import *
from temp_control.fuzzy_pid import * 

#作为heater
DP832 = DP832('USB0::0x1AB1::0x0E11::DP8C245007180::0::INSTR')
# m211 = Model_211('ASRL3::INSTR')
# pid_control = PID(9.6,7.5,16,5)
#作为sensor
SM2450_sense = SM_2450('USB0::0x05E6::0x2450::04595034::0::INSTR')

dataset = sio.loadmat(r'C:\Users\yanghaoran\Desktop\EXPERIMENT\temp_control\data.mat')
dataset.keys()
sense_trans = dataset['vol_i']
tem_sense_vol = [inner for outer in sense_trans for inner in outer]

# #查询数组长度(此处插值后长度为4861)
# length = len(data_vol)
# print(length)
# 线性映射之后，tem_i = 0.01*i+1.4; vol_i = data_vol[i];
# 此处的tem_sense_vol为在给电流为10uA的情况下每一个tem所对应的voltage
# 将tem_sense_vol变换为二维数组

#创建一个行为4861，列为2的二维数组,用来保存一一对应的tem和vol
rows = 4861
cols = 2
tem_sense_array = [[None] * cols for _ in range(rows)]
for i in range(len(tem_sense_vol)):
    tem_sense_array[i][0] = tem_sense_vol[i]
    tem_sense_array[i][1] = 0.01*i+1.4


# #PART1：The automatic temperature read module
# #此处为了减少时间复杂度，调用平衡二叉树生成Module，便于寻址和温度的计算

#生成平衡二叉树
avl_tem_tree = None
for i in range(len(tem_sense_vol)):
    avl_tem_tree = insert(avl_tem_tree,tem_sense_array[i][0],tem_sense_array[i][1])
#
# #储存所读取到的电压值
# MEAS_VOL = float(SM2450_sense.measure_voltage())
# #print(MEAS_VOL)

# # #对所生成的二叉树进行遍历以便找到所对应的温度值
# # data_tem = np.append(data_tem,Search_AVLtree(MEAS_VOL, avl_tem_tree))
# data_tem = Search_AVLtree(MEAS_VOL,avl_tem_tree)

# #PART2:  The automatic temperature control module（先实现对于某一个温度的值的稳定）
# DP832.set_current('ch2',0.5)
# set_tem=float(input("请输入设定的温度值： "))

#关键在于求解实时更新的电压值（使用LMS-PID算法稳定温度）
vol_tempo = 0
last_t = 0

error = 0
derta_error = 0
scale = 5

#直接传参调节PID控制器系数
kp = 9.6
ki = 7.5
kd = 16


while(1):    
        #模糊PID算法计算PID控制器系数
        # kp = Cau_fuzzy_PID_kp(error,derta_error)
        # ki = Cau_fuzzy_PID_ki(error,derta_error)
        # kd = Cau_fuzzy_PID_kd(error,derta_error)
        pid_control = PID(kp,ki,kd,scale)
        MEAS_VOL = float(SM2450_sense.measure_voltage())
        data_tem = Search_AVLtree(MEAS_VOL,avl_tem_tree)
        error = set_tem - data_tem
        now_t = millis()
        #位置式PID/加上外循环可准变为模糊PID控制器
        vol_tempo = pid_control.get_pid(error,1)
        #直接型模糊控制，可能更不准
        # vol_tempo = Cau_fuzzy_PID(error,derta_error)
        DP832.set_voltage('ch1', vol_tempo)
        DP832.set_current('ch1', 1)
        #模糊PID控制，结合模糊控制和PID控制，把模糊控制控制到Kp、Ki、Kd上，可以达到更精确的控制
        D_error = error - last_error
        last_error = error
        d_t = float(now_t - last_t)/float(1000)
        last_t = now_t 
        #模糊控制实际代码
        # vol_tempo = Cau_fuzzy_PID(error,derta_error)
        # DP832.set_voltage('ch1', vol_tempo)
        # DP832.set_current('ch1', 1)
        
        if(derta < 0.01 and D_error/d_t < 1):
            break
         
#//可视化噪声
#寻址计算实时温度
data_tem = []
for i in range (4680):
    data_tem = np.append(data_tem,Search_AVLtree(MEAS_VOL, avl_tem_tree))
    time.sleep(0.001)

#温度可视化绘图
x = np.arange(0,4680,1)
print(x)
y = data_tem
print(y)
plt.show()
plt.plot(x,y)
plt.grid(True)
plt.xlabel("i")
plt.ylabel("tem")
plt.title("temperature")







