# -*- coding: utf-8 -*-
"""
Created on Wed Jul 24 15:52:16 2024

@author: yanghaoran
"""

import numpy as np
import skfuzzy as fuzz
import skfuzzy.control as ctrl


#定义模糊变量

error_range = np.arrange(0)
derta_error_range = np.arrange(0)
output_range = np.arrange(0) 

error = ctrl.Antecedent(error_range, 'error')
derta_error = ctrl.Antecedent(derta_error_range, 'derta_error')
output = ctrl.Consequent(output_range, 'output')

# 定义模糊集和其隶属度函数

error['NB'] = fuzz.trimf(error.universe,[])
error['NM'] = fuzz.trimf(error.universe,[])
error['NS'] = fuzz.trimf(error.universe,[])
error['ZO'] = fuzz.trimf(error.universe,[]) 
error['PS'] = fuzz.trimf(error.universe,[])
error['PM'] = fuzz.trimf(error.universe,[])
error['PB'] = fuzz.trimf(error.universe,[])

#定义模糊规则

derta_error['NB'] = fuzz.trimf(derta_error.universe,[])
derta_error['NM'] = fuzz.trimf(derta_error.universe,[])
derta_error['NS'] = fuzz.trimf(derta_error.universe,[])
derta_error['ZO'] = fuzz.trimf(derta_error.universe,[])
derta_error['PS'] = fuzz.trimf(derta_error.universe,[])
derta_error['PM'] = fuzz.trimf(derta_error.universe,[])
derta_error['PB'] = fuzz.trimf(derta_error.universe,[])

output['NB'] = fuzz.trimf(output.universe,[])
output['NM'] = fuzz.trimf(output.universe,[])
output['NS'] = fuzz.trimf(output.universe,[])
output['ZO'] = fuzz.trimf(output.universe,[])
output['PS'] = fuzz.trimf(output.universe,[])
output['PM'] = fuzz.trimf(output.universe,[])
output['PB'] = fuzz.trimf(output.universe,[])

#kp模糊控制规则
kp_rule1 = ctrl.kp_rule(error['NB'] & derta_error['NB'], output['PB'])
kp_rule2 = ctrl.kp_rule(error['NB'] & derta_error['NM'], output['PB'])
kp_rule3 = ctrl.kp_rule(error['NB'] & derta_error['NS'], output['PB'])
kp_rule4 = ctrl.kp_rule(error['NB'] & derta_error['ZO'], output['PB'])
kp_rule5 = ctrl.kp_rule(error['NB'] & derta_error['PS'], output['PM'])
kp_rule6 = ctrl.kp_rule(error['NB'] & derta_error['PM'], output['PS'])
kp_rule7 = ctrl.kp_rule(error['NB'] & derta_error['PB'], output['ZO'])

kp_rule8 = ctrl.kp_rule(error['NM'] & derta_error['NB'], output['PB'])
kp_rule9 = ctrl.kp_rule(error['NM'] & derta_error['NM'], output['PB'])
kp_rule10 = ctrl.kp_rule(error['NM'] & derta_error['NS'], output['PB'])
kp_rule11 = ctrl.kp_rule(error['NM'] & derta_error['ZO'], output['PB'])
kp_rule12 = ctrl.kp_rule(error['NM'] & derta_error['PS'], output['PM'])
kp_rule13 = ctrl.kp_rule(error['NM'] & derta_error['PM'], output['ZO'])
kp_rule14 = ctrl.kp_rule(error['NM'] & derta_error['PB'], output['ZO'])

kp_rule15 = ctrl.kp_rule(error['NS'] & derta_error['NB'], output['PM'])
kp_rule16 = ctrl.kp_rule(error['NS'] & derta_error['NM'], output['PM'])
kp_rule17 = ctrl.kp_rule(error['NS'] & derta_error['NS'], output['PM'])
kp_rule18 = ctrl.kp_rule(error['NS'] & derta_error['ZO'], output['PM'])
kp_rule19 = ctrl.kp_rule(error['NS'] & derta_error['PS'], output['ZO'])
kp_rule20 = ctrl.kp_rule(error['NS'] & derta_error['PM'], output['PS'])
kp_rule21 = ctrl.kp_rule(error['NS'] & derta_error['PB'], output['PS'])

kp_rule22 = ctrl.kp_rule(error['ZO'] & derta_error['NB'], output['PM'])
kp_rule23 = ctrl.kp_rule(error['ZO'] & derta_error['NM'], output['PM'])
kp_rule24 = ctrl.kp_rule(error['ZO'] & derta_error['NS'], output['PS'])
kp_rule25 = ctrl.kp_rule(error['ZO'] & derta_error['ZO'], output['ZO'])
kp_rule26 = ctrl.kp_rule(error['ZO'] & derta_error['PS'], output['NS'])
kp_rule27 = ctrl.kp_rule(error['ZO'] & derta_error['PM'], output['NS'])
kp_rule28 = ctrl.kp_rule(error['ZO'] & derta_error['PB'], output['NM'])

kp_rule29 = ctrl.kp_rule(error['PS'] & derta_error['NB'], output['PS'])
kp_rule30 = ctrl.kp_rule(error['PS'] & derta_error['NM'], output['PS'])
kp_rule31 = ctrl.kp_rule(error['PS'] & derta_error['NS'], output['ZO'])
kp_rule32 = ctrl.kp_rule(error['PS'] & derta_error['ZO'], output['NS'])
kp_rule33 = ctrl.kp_rule(error['PS'] & derta_error['PS'], output['NM'])
kp_rule34 = ctrl.kp_rule(error['PS'] & derta_error['PM'], output['NM'])
kp_rule35 = ctrl.kp_rule(error['PS'] & derta_error['PB'], output['NM'])

kp_rule36 = ctrl.kp_rule(error['PB'] & derta_error['NB'], output['PS'])
kp_rule37 = ctrl.kp_rule(error['PB'] & derta_error['NM'], output['ZO'])
kp_rule38 = ctrl.kp_rule(error['PB'] & derta_error['NS'], output['NS'])
kp_rule39 = ctrl.kp_rule(error['PB'] & derta_error['ZO'], output['NM'])
kp_rule40 = ctrl.kp_rule(error['PB'] & derta_error['PS'], output['NM'])
kp_rule41 = ctrl.kp_rule(error['PB'] & derta_error['PM'], output['NM'])
kp_rule42 = ctrl.kp_rule(error['PB'] & derta_error['PB'], output['NB'])

kp_rule43 = ctrl.kp_rule(error['PM'] & derta_error['NB'], output['ZO'])
kp_rule44 = ctrl.kp_rule(error['PM'] & derta_error['NM'], output['ZO'])
kp_rule45 = ctrl.kp_rule(error['PM'] & derta_error['NS'], output['NM'])
kp_rule46 = ctrl.kp_rule(error['PM'] & derta_error['ZO'], output['NM'])
kp_rule47 = ctrl.kp_rule(error['PM'] & derta_error['PS'], output['NM'])
kp_rule48 = ctrl.kp_rule(error['PM'] & derta_error['PM'], output['NB'])
kp_rule49 = ctrl.kp_rule(error['PM'] & derta_error['PB'], output['NB'])


#ki模糊控制规则
ki_rule1 = ctrl.ki_rule(error['NB'] & derta_error['NB'], output['NB'])
ki_rule2 = ctrl.ki_rule(error['NB'] & derta_error['NM'], output['NB'])
ki_rule3 = ctrl.ki_rule(error['NB'] & derta_error['NS'], output['NM'])
ki_rule4 = ctrl.ki_rule(error['NB'] & derta_error['ZO'], output['NM'])
ki_rule5 = ctrl.ki_rule(error['NB'] & derta_error['PS'], output['NS'])
ki_rule6 = ctrl.ki_rule(error['NB'] & derta_error['PM'], output['ZO'])
ki_rule7 = ctrl.ki_rule(error['NB'] & derta_error['PB'], output['ZO'])

ki_rule8 = ctrl.ki_rule(error['NM'] & derta_error['NB'], output['NB'])
ki_rule9 = ctrl.ki_rule(error['NM'] & derta_error['NM'], output['NB'])
ki_rule10 = ctrl.ki_rule(error['NM'] & derta_error['NS'], output['NM'])
ki_rule11 = ctrl.ki_rule(error['NM'] & derta_error['ZO'], output['NS'])
ki_rule12 = ctrl.ki_rule(error['NM'] & derta_error['PS'], output['NS'])
ki_rule13 = ctrl.ki_rule(error['NM'] & derta_error['PM'], output['ZO'])
ki_rule14 = ctrl.ki_rule(error['NM'] & derta_error['PB'], output['ZO'])

ki_rule15 = ctrl.ki_rule(error['NS'] & derta_error['NB'], output['NB'])
ki_rule16 = ctrl.ki_rule(error['NS'] & derta_error['NM'], output['NM'])
ki_rule17 = ctrl.ki_rule(error['NS'] & derta_error['NS'], output['NS'])
ki_rule18 = ctrl.ki_rule(error['NS'] & derta_error['ZO'], output['NS'])
ki_rule19 = ctrl.ki_rule(error['NS'] & derta_error['PS'], output['ZO'])
ki_rule20 = ctrl.ki_rule(error['NS'] & derta_error['PM'], output['PS'])
ki_rule21 = ctrl.ki_rule(error['NS'] & derta_error['PB'], output['PS'])

ki_rule22 = ctrl.ki_rule(error['ZO'] & derta_error['NB'], output['NM'])
ki_rule23 = ctrl.ki_rule(error['ZO'] & derta_error['NM'], output['NM'])
ki_rule24 = ctrl.ki_rule(error['ZO'] & derta_error['NS'], output['NS'])
ki_rule25 = ctrl.ki_rule(error['ZO'] & derta_error['ZO'], output['ZO'])
ki_rule26 = ctrl.ki_rule(error['ZO'] & derta_error['PS'], output['PS'])
ki_rule27 = ctrl.ki_rule(error['ZO'] & derta_error['PM'], output['PM'])
ki_rule28 = ctrl.ki_rule(error['ZO'] & derta_error['PB'], output['PM'])

ki_rule29 = ctrl.ki_rule(error['PS'] & derta_error['NB'], output['NM'])
ki_rule30 = ctrl.ki_rule(error['PS'] & derta_error['NM'], output['NS'])
ki_rule31 = ctrl.ki_rule(error['PS'] & derta_error['NS'], output['ZO'])
ki_rule32 = ctrl.ki_rule(error['PS'] & derta_error['ZO'], output['PS'])
ki_rule33 = ctrl.ki_rule(error['PS'] & derta_error['PS'], output['PS'])
ki_rule34 = ctrl.ki_rule(error['PS'] & derta_error['PM'], output['PM'])
ki_rule35 = ctrl.ki_rule(error['PS'] & derta_error['PB'], output['PB'])

ki_rule36 = ctrl.ki_rule(error['PB'] & derta_error['NB'], output['ZO'])
ki_rule37 = ctrl.ki_rule(error['PB'] & derta_error['NM'], output['ZO'])
ki_rule38 = ctrl.ki_rule(error['PB'] & derta_error['NS'], output['PS'])
ki_rule39 = ctrl.ki_rule(error['PB'] & derta_error['ZO'], output['NM'])
ki_rule40 = ctrl.ki_rule(error['PB'] & derta_error['PS'], output['PM'])
ki_rule41 = ctrl.ki_rule(error['PB'] & derta_error['PM'], output['PB'])
ki_rule42 = ctrl.ki_rule(error['PB'] & derta_error['PB'], output['PB'])

ki_rule43 = ctrl.ki_rule(error['PM'] & derta_error['NB'], output['ZO'])
ki_rule44 = ctrl.ki_rule(error['PM'] & derta_error['NM'], output['ZO'])
ki_rule45 = ctrl.ki_rule(error['PM'] & derta_error['NS'], output['PS'])
ki_rule46 = ctrl.ki_rule(error['PM'] & derta_error['ZO'], output['PM'])
ki_rule47 = ctrl.ki_rule(error['PM'] & derta_error['PS'], output['PM'])
ki_rule48 = ctrl.ki_rule(error['PM'] & derta_error['PM'], output['PB'])
ki_rule49 = ctrl.ki_rule(error['PM'] & derta_error['PB'], output['PB'])


#kd模糊控制规则
kd_rule1 = ctrl.kd_rule(error['NB'] & derta_error['NB'], output['PS'])
kd_rule2 = ctrl.kd_rule(error['NB'] & derta_error['NM'], output['NS'])
kd_rule3 = ctrl.kd_rule(error['NB'] & derta_error['NS'], output['NB'])
kd_rule4 = ctrl.kd_rule(error['NB'] & derta_error['ZO'], output['NB'])
kd_rule5 = ctrl.kd_rule(error['NB'] & derta_error['PS'], output['NB'])
kd_rule6 = ctrl.kd_rule(error['NB'] & derta_error['PM'], output['NM'])
kd_rule7 = ctrl.kd_rule(error['NB'] & derta_error['PB'], output['PS'])

kd_rule8 = ctrl.kd_rule(error['NM'] & derta_error['NB'], output['PS'])
kd_rule9 = ctrl.kd_rule(error['NM'] & derta_error['NM'], output['NS'])
kd_rule10 = ctrl.kd_rule(error['NM'] & derta_error['NS'], output['NB'])
kd_rule11 = ctrl.kd_rule(error['NM'] & derta_error['ZO'], output['NM'])
kd_rule12 = ctrl.kd_rule(error['NM'] & derta_error['PS'], output['NM'])
kd_rule13 = ctrl.kd_rule(error['NM'] & derta_error['PM'], output['NS'])
kd_rule14 = ctrl.kd_rule(error['NM'] & derta_error['PB'], output['ZO'])

kd_rule15 = ctrl.kd_rule(error['NS'] & derta_error['NB'], output['ZO'])
kd_rule16 = ctrl.kd_rule(error['NS'] & derta_error['NM'], output['NS'])
kd_rule17 = ctrl.kd_rule(error['NS'] & derta_error['NS'], output['NM'])
kd_rule18 = ctrl.kd_rule(error['NS'] & derta_error['ZO'], output['NM'])
kd_rule19 = ctrl.kd_rule(error['NS'] & derta_error['PS'], output['NS'])
kd_rule20 = ctrl.kd_rule(error['NS'] & derta_error['PM'], output['NS'])
kd_rule21 = ctrl.kd_rule(error['NS'] & derta_error['PB'], output['ZO'])

kd_rule22 = ctrl.kd_rule(error['ZO'] & derta_error['NB'], output['ZO'])
kd_rule23 = ctrl.kd_rule(error['ZO'] & derta_error['NM'], output['NS'])
kd_rule24 = ctrl.kd_rule(error['ZO'] & derta_error['NS'], output['NS'])
kd_rule25 = ctrl.kd_rule(error['ZO'] & derta_error['ZO'], output['NS'])
kd_rule26 = ctrl.kd_rule(error['ZO'] & derta_error['PS'], output['NS'])
kd_rule27 = ctrl.kd_rule(error['ZO'] & derta_error['PM'], output['NS'])
kd_rule28 = ctrl.kd_rule(error['ZO'] & derta_error['PB'], output['ZO'])

kd_rule29 = ctrl.kd_rule(error['PS'] & derta_error['NB'], output['ZO'])
kd_rule30 = ctrl.kd_rule(error['PS'] & derta_error['NM'], output['ZO'])
kd_rule31 = ctrl.kd_rule(error['PS'] & derta_error['NS'], output['ZO'])
kd_rule32 = ctrl.kd_rule(error['PS'] & derta_error['ZO'], output['ZO'])
kd_rule33 = ctrl.kd_rule(error['PS'] & derta_error['PS'], output['ZO'])
kd_rule34 = ctrl.kd_rule(error['PS'] & derta_error['PM'], output['ZO'])
kd_rule35 = ctrl.kd_rule(error['PS'] & derta_error['PB'], output['ZO'])

kd_rule36 = ctrl.kd_rule(error['PB'] & derta_error['NB'], output['PB'])
kd_rule37 = ctrl.kd_rule(error['PB'] & derta_error['NM'], output['PS'])
kd_rule38 = ctrl.kd_rule(error['PB'] & derta_error['NS'], output['PS'])
kd_rule39 = ctrl.kd_rule(error['PB'] & derta_error['ZO'], output['PS'])
kd_rule40 = ctrl.kd_rule(error['PB'] & derta_error['PS'], output['PS'])
kd_rule41 = ctrl.kd_rule(error['PB'] & derta_error['PM'], output['PS'])
kd_rule42 = ctrl.kd_rule(error['PB'] & derta_error['PB'], output['PB'])

kd_rule43 = ctrl.kd_rule(error['PM'] & derta_error['NB'], output['PB'])
kd_rule44 = ctrl.kd_rule(error['PM'] & derta_error['NM'], output['PM'])
kd_rule45 = ctrl.kd_rule(error['PM'] & derta_error['NS'], output['PM'])
kd_rule46 = ctrl.kd_rule(error['PM'] & derta_error['ZO'], output['PM'])
kd_rule47 = ctrl.kd_rule(error['PM'] & derta_error['PS'], output['PS'])
kd_rule48 = ctrl.kd_rule(error['PM'] & derta_error['PM'], output['PS'])
kd_rule49 = ctrl.kd_rule(error['PM'] & derta_error['PB'], output['PB'])


#控制系统
pid_ctrl_kp = ctrl.ControlSystem(
    [kp_rule1,kp_rule2,kp_rule3,kp_rule4,kp_rule5,kp_rule6,kp_rule7,
     kp_rule8,kp_rule9,kp_rule10,kp_rule11,kp_rule12,kp_rule13,kp_rule14,
     kp_rule15,kp_rule16,kp_rule17,kp_rule18,kp_rule19,kp_rule20,kp_rule21,
     kp_rule22,kp_rule23,kp_rule24,kp_rule25,kp_rule26,kp_rule27,kp_rule28,
     kp_rule29,kp_rule30,kp_rule31,kp_rule32,kp_rule33,kp_rule34,kp_rule35,
     kp_rule36,kp_rule37,kp_rule38,kp_rule39,kp_rule40,kp_rule41,kp_rule42,
     kp_rule43,kp_rule44,kp_rule45,kp_rule46,kp_rule47,kp_rule48,kp_rule49])

pid_ctrl_ki = ctrl.ControlSystem(
    [ki_rule1,ki_rule2,ki_rule3,ki_rule4,ki_rule5,ki_rule6,ki_rule7,
     ki_rule8,ki_rule9,ki_rule10,ki_rule11,ki_rule12,ki_rule13,ki_rule14,
     ki_rule15,ki_rule16,ki_rule17,ki_rule18,ki_rule19,ki_rule20,ki_rule21,
     ki_rule22,ki_rule23,ki_rule24,ki_rule25,ki_rule26,ki_rule27,ki_rule28,
     ki_rule29,ki_rule30,ki_rule31,ki_rule32,ki_rule33,ki_rule34,ki_rule35,
     ki_rule36,ki_rule37,ki_rule38,ki_rule39,ki_rule40,ki_rule41,ki_rule42,
     ki_rule43,ki_rule44,ki_rule45,ki_rule46,ki_rule47,ki_rule48,ki_rule49])

pid_ctrl_kd = ctrl.ControlSystem(
    [kd_rule1,kd_rule2,kd_rule3,kd_rule4,kd_rule5,kd_rule6,kd_rule7,
     kd_rule8,kd_rule9,kd_rule10,kd_rule11,kd_rule12,kd_rule13,kd_rule14,
     kd_rule15,kd_rule16,kd_rule17,kd_rule18,kd_rule19,kd_rule20,kd_rule21,
     kd_rule22,kd_rule23,kd_rule24,kd_rule25,kd_rule26,kd_rule27,kd_rule28,
     kd_rule29,kd_rule30,kd_rule31,kd_rule32,kd_rule33,kd_rule34,kd_rule35,
     kd_rule36,kd_rule37,kd_rule38,kd_rule39,kd_rule40,kd_rule41,kd_rule42,
     kd_rule43,kd_rule44,kd_rule45,kd_rule46,kd_rule47,kd_rule48,kd_rule49])

#调用函数类型
class fuzzy_PID:
    def __init__(self,error,derta_error):
        self.error = error
        self.derta_error = derta_error

    def Cau_fuzzy_PID_kp(self,error,derta_error):
        fuzzy_pid = ctrl.ControlSystemSimulation(pid_ctrl_kp)
        
        fuzzy_pid.input['error'] = error
        fuzzy_pid.input['derta_error'] = derta_error
        fuzzy_pid.compute()
        
        return fuzzy_pid.output
    
    def Cau_fuzzy_PID_ki(self,error,derta_error):
        fuzzy_pid = ctrl.ControlSystemSimulation(pid_ctrl_ki)
        
        fuzzy_pid.input['error'] = error
        fuzzy_pid.input['derta_error'] = derta_error
        fuzzy_pid.compute()
        
        return fuzzy_pid.output
    
    def Cau_fuzzy_PID_kd(self,error,derta_error):
        fuzzy_pid = ctrl.ControlSystemSimulation(pid_ctrl_kd)
        
        fuzzy_pid.input['error'] = error
        fuzzy_pid.input['derta_error'] = derta_error
        fuzzy_pid.compute()
        
        return fuzzy_pid.output