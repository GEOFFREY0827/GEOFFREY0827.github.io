# -*- coding: utf-8 -*-
"""
Created on Sun Apr 14 19:35:03 2024

@author: yanghaoran
"""

import pyvisa
import visa
import numpy as np
from matplotlib import pyplot as plt
from scipy.optimize import fmin
import scipy.io
import os
from DP832 import *
from Instruments_communication.Model_211 import *
from temp_control.PID import *
from SM_2450 import *

sm2450 = SM_2450('USB0::0x05E6::0x2450::04595034::0::INSTR')

data_tem = np.array([])

data_tem =np.append(data_tem, sm2450.measure_current(20,5,50,0.01))

print(data_tem)
