# -*- coding: utf-8 -*-
"""
Created on Wed Apr 10 23:21:09 2024

@author: yanghaoran
"""

import pyvisa
import visa
import numpy as np
from matplotlib import pyplot as plt
from scipy.optimize import fmin
import scipy.io
import os
from DP832 import *
from Instruments_communication.Model_211 import *
from temp_control.PID import *
from Instruments_communication.SM_2400 import *

sm2400 = SM_2400('ASRL12::INSTR')



sm2400.output_cur(0.2)