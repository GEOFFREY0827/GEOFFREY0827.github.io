# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 08:38:44 2024

@author: yanghaoran
"""

from visa import *
import pyvisa
import time

_delay = 0.01  # in seconds


class Model_211(object):
    # def __init__(self, usb_or_serial='USB0'):
    #     try:
    #         self.rm = visa.ResourceManager()
    #         self.instrument_list = self.rm.list_resources()

    #         self.address = [elem for elem in self.instrument_list if (elem.find('USB') != -1 and elem.find(
    #             usb_or_serial) != -1)]  # Search a instrument with USB and serial number in the instrument list

    #         if self.address.__len__() == 0:
    #             self.status = "Not Connected"
    #             # print("Could not connect to device")
    #         else:
    #             self.address = self.address[0]
    #             self.device = self.rm.open_resource(self.address)
    #             # print("Connected to " + self.address)
    #             self.status = "Connected"
    #             self.connected_with = 'USB'

    #     except VisaIOError:
    #         self.status = "Not Connected"
    #         # print("PyVISA is not able to find any devices")
   def _read_raw_Model_211(self):
        """Read the unmodified string sent from the instrument to the computer.

        In contrast to read(), no termination characters are stripped.

        Parameters
        ----------
        size : Optional[int], optional
            The chunk size to use to perform the reading. Defaults to None,
            meaning the resource wide set value is set.

        Returns
        -------
        bytearray
            Bytes read from the instrument.

        """
        size = self.chunk_size if size is None else size

        loop_status = constants.StatusCode.success_max_count_read

        ret = bytearray()
        with self.ignore_warning(
            constants.StatusCode.success_device_not_present,
            constants.StatusCode.success_max_count_read,
        ):
            try:
                status = loop_status
                while status == loop_status:
                    logger.debug(
                        "%s - reading %d bytes (last status %r)",
                        self._resource_name,
                        size,
                        status,
                    )
                    chunk, status = self.visalib.read(self.session, size)
                    ret.extend(chunk)
            except errors.VisaIOError as e:
                logger.debug(
                    "%s - exception while reading: %s\nBuffer " "content: %r",
                    self._resource_name,
                    e,
                    ret,
                )
                raise

        return ret