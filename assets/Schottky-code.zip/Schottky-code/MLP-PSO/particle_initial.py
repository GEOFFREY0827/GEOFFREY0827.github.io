import pandas as pd
import numpy as np
import copy
def particle_generate(bounds,particle_num):
    particle = np.zeros((particle_num,5))
    for i in range(particle_num):
        particle[i][1] = np.random.uniform(bounds[1][0], bounds[1][1], 1) #b随机生成
        particle[i][3] = np.random.uniform(bounds[3][0], bounds[3][1], 1) #d随机生成
        particle[i][0] = np.random.uniform(0,bounds[0][1]-max(particle[i][1],particle[i][3]), 1) #a随机生成
        while (particle[i][0] == 0 ):
            particle[i][0] = np.random.uniform(0,bounds[0][1]-max(particle[i][1],particle[i][3]), 1) #a随机生成
        
        particle[i][2] = np.random.uniform(0,bounds[2][1]-max(particle[i][1],particle[i][3]), 1) #c随机生成
        while (particle[i][2] == 0):
            particle[i][2] = np.random.uniform(0,bounds[2][1]-max(particle[i][1],particle[i][3]), 1) #c随机生成
        
        particle[i][4] = np.random.uniform(0, bounds[4][1]-max(particle[i][1],particle[i][3])-particle[i][0], 1) #e随机生成
        while (particle[i][4] == 0):
            particle[i][4] = np.random.uniform(0, bounds[4][1]-max(particle[i][1],particle[i][3])-particle[i][0], 1) #e随机生成
    return particle

def particles_decode(particle,particle_num):
    t = 0
    a = copy.deepcopy(particle)
    for i in range(particle_num):
        t = a[i][0]
        a[i][0] =  a[i][0]+max(a[i][1],a[i][3]) #a解码
        a[i][2] =  a[i][2]+max(a[i][1],a[i][3]) #c解码
        a[i][4] =  t+a[i][4]+max(a[i][1],a[i][3])#e解码

    return a

def particle_decode(particle):
    t = [0]
    a = copy.deepcopy(particle)
    a[0] =  a[0]+max(a[1],a[3]) #a解码
    a[2] =  a[2]+max(a[1],a[3]) #c解码
    a[4] =  t+a[4]+max(a[1],a[3])#e解码

    return a