
import numpy as np
import pandas as pd

# 初始化一个空列表来存储每个 output_data 的 NumPy 数组
output_arrays = []

for i in range(460):
    output_data = pd.read_csv(f'E:\\Schottky_result_CSV\\result_3000\\absorptivity_{i}.csv')
    output_data = output_data.iloc[:, 1:2]
    output_data = output_data.to_numpy()
    output_data = np.transpose(output_data)
    output_arrays.append(output_data)  # 将数组添加到列表中

# 沿着水平方向（axis=1）拼接所有 output_data
output_array = np.concatenate(output_arrays, axis=0)

# 读取 input_data
input_data = pd.read_csv(f'E:\\Schottky_result_CSV\\result_3000\\parameters_3000.csv')
input_data = input_data.iloc[0:460, :]

print(input_data.shape)
print(output_array.shape)
# 沿着列方向（axis=1）拼接 input_data 和 output_df
combined_data = np.concatenate([input_data, output_array], axis=1)
print([input_data, output_array])
# 将 NumPy 数组转换为 Pandas DataFrame
combined_data = pd.DataFrame(combined_data)
# 保存合并后的数据到 CSV 文件
combined_data.to_csv(f'E:\\Schottky_result_CSV\\combined_data.csv', index=False)
