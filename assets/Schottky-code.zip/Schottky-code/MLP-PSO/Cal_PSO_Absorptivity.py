import pandas as pd
import numpy as np

def cal_ave_absorp_PSO(absobtivity_predict, wavelength_min_nm, wavelength_max_nm):
    """
    计算指定文件在给定波长范围内的平均吸收率。

    参数:
    - file_path: str, CSV文件路径
    - wavelength_min_nm: float, 波长范围下限（单位：纳米）
    - wavelength_max_nm: float, 波长范围上限（单位：纳米）

    返回:
    - avg_absorptivity: float, 平均吸收率，如果出错则返回None
    """
  
    wavelengths_nm = []
    for i in range(300):
        wavelengths_nm.append(1000+10*i)
        
    absorptivities = absobtivity_predict[0]

    wavelengths_nm = np.array(wavelengths_nm)
    absorptivities = np.array(absorptivities)
    # 筛选指定波段范围内的数据
    mask = (wavelengths_nm >= wavelength_min_nm) & (wavelengths_nm <= wavelength_max_nm)
    filtered_wavelengths = wavelengths_nm[mask]
    filtered_absorptivities = absorptivities[mask]

    # 检查筛选后的数据是否为空
    if len(filtered_wavelengths) == 0:
        raise ValueError("指定波长范围内没有数据。")

    # 使用梯形法计算积分
    integral = np.trapz(filtered_absorptivities, filtered_wavelengths)

    # 计算波长值范围
    wavelength_range = filtered_wavelengths[-1] - filtered_wavelengths[0]

    # 计算平均吸收率
    avg_absorptivity = integral / wavelength_range

    return avg_absorptivity

