import os
import pandas as pd
import numpy as np
import glob


def calculate_average_absorptivity(file_path, wavelength_min_nm, wavelength_max_nm):
    """
    计算指定文件在给定波长范围内的平均吸收率。

    参数:
    - file_path: str, CSV文件路径
    - wavelength_min_nm: float, 波长范围下限（单位：纳米）
    - wavelength_max_nm: float, 波长范围上限（单位：纳米）

    返回:
    - avg_absorptivity: float, 平均吸收率，如果出错则返回None
    """
    try:
        # 读取CSV文件
        df = pd.read_csv(file_path)

        # 检查所需列是否存在
        required_columns = ['Wavelength (nm)', 'Absorptivity']
        if not all(col in df.columns for col in required_columns):
            raise ValueError(f"文件 {file_path} 缺少必要的列: {required_columns}")

        wavelengths_nm = df['Wavelength (nm)'].values
        absorptivities = df['Absorptivity'].values

        # 筛选指定波段范围内的数据
        mask = (wavelengths_nm >= wavelength_min_nm) & (wavelengths_nm <= wavelength_max_nm)
        filtered_wavelengths = wavelengths_nm[mask]
        filtered_absorptivities = absorptivities[mask]

        # 检查筛选后的数据是否为空
        if len(filtered_wavelengths) == 0:
            raise ValueError("指定波长范围内没有数据。")

        # 使用梯形法计算积分
        integral = np.trapz(filtered_absorptivities, filtered_wavelengths)

        # 计算波长值范围
        wavelength_range = filtered_wavelengths[-1] - filtered_wavelengths[0]

        # 计算平均吸收率
        avg_absorptivity = integral / wavelength_range

        return avg_absorptivity
    except Exception as e:
        print(f"处理文件 {file_path} 时出错: {e}")
        return None


# def process_folder(input_folder, output_csv, wavelength_min_nm, wavelength_max_nm):
#     """
#     处理指定文件夹中的所有CSV文件，计算平均吸收率，并保存结果到新的CSV文件。

#     参数:
#     - input_folder: str, 输入文件夹路径
#     - output_csv: str, 输出CSV文件路径
#     - wavelength_min_nm: float, 波长范围下限（单位：纳米）
#     - wavelength_max_nm: float, 波长范围上限（单位：纳米）
#     """
#     # 使用glob获取所有CSV文件
#     csv_pattern = os.path.join(input_folder, '*.csv')
#     csv_files = glob.glob(csv_pattern)
#     print(f"找到 {len(csv_files)} 个CSV文件。")

#     results = []

#     for file_path in csv_files:
#         avg_absorptivity = calculate_average_absorptivity(file_path, wavelength_min_nm, wavelength_max_nm)
#         if avg_absorptivity is not None:
#             file_name = os.path.basename(file_path)
#             results.append({
#                 'File Name': file_name,
#                 'Average Absorptivity': avg_absorptivity
#             })
#         else:
#             print(f"跳过文件 {file_path}，因为处理时出错。")

#     # 将结果转换为DataFrame
#     results_df = pd.DataFrame(results)

#     # 保存到CSV
#     results_df.to_csv(output_csv, index=False)
#     print(f"结果已保存到 {output_csv}")

# # 假设你希望处理文件夹中的所有文件，请定义输入文件夹和波段范围
# input_folder = 'E:\Al\python_sweep/all_5_param/Co/'  # 替换为你的文件夹路径
# output_csv = 'average_absorptivity_results_Co_1450-1650.csv'
# wavelength_min_nm = 1450  # 例如1000 nm
# wavelength_max_nm = 1650  # 例如3000 nm

# process_folder(input_folder, output_csv, wavelength_min_nm, wavelength_max_nm)
