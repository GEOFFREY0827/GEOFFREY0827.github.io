import os
import ctypes
import numpy as np
import pandas as pd
from absorptivity import *

# 设置 'interopapi.dll' 文件的路径
lumerical_path = 'C:\Program Files\Lumerical/v241/api\python'
interopapi_path = os.path.join(lumerical_path, 'interopapi.dll')

# 手动加载 'interopapi.dll'
try:
    lumapi = ctypes.CDLL(interopapi_path)
except Exception as e:
    print(f"Error: {e}")
    raise SystemExit

# 导入Lumerical的Python API模块
import sys
sys.path.append('C:\Program Files\Lumerical/v241/api\python')
import lumapi

# 设置FDTD工作目录和文件名
file_path = "E:\FDTD_Simulation"
file_name = "Al-W-Co-Si-1.fsp"

# 定义新的绝对路径(存有结构参数struc1000.csv的路径)
save_path = 'E:\Schottky_result_CSV/'

# 定义结构参数文件名的前缀和文件数量
prefix = "structure_parameters"
#num_files = 5  \\？为啥有这一句

# 定义结构参数文件名
csv_filename = f'{save_path}{prefix}.csv'

# 读取CSV文件，并假设文件包含c、l、w、d、b等结构参数
df_params = pd.read_csv(csv_filename)

#定义所仿数据轮数为epoches
epoches = 100
t = 0

with lumapi.FDTD() as fdtd:
    fdtd.cd(file_path)
    fdtd.load(file_name)

    fdtd.switchtolayout()
    
    for index, row in df_params.iterrows():
        # 从CSV文件中读取结构参数c、l、w、d、b、T_x、T_y
        c = row['c'] * 1e-6  # 转换为微米
        l = row['l'] * 1e-6  # 转换为微米
        w = row['w'] * 1e-6  # 转换为微米
        d = row['d'] * 1e-6  # 转换为微米
        b = row['b'] * 1e-6  # 转换为微米
        T_x = row['T_x']
        T_y = row['T_y']
        x_span = T_x*(l+b)
        y_span = T_y*(d+w)
        x0 = 6.759*1e-6
        y0 = 31.097*1e-6

        # 设置结构参数
        fdtd.switchtolayout()
        Co_Si_FDTD_X_min = x0-(T_x//2+(T_x%2))*(l+b+2*c)
        Co_Si_FDTD_X_max = x0+(T_x//2+(T_x%2)-1)*(l+b+2*c)
        Co_Si_FDTD_Y_min = y0-(T_y//2+(T_y%2)-1)*(d+w)
        Co_Si_FDTD_Y_max = y0+(T_y//2+(T_y%2))*(d+w)
        # 设置 FDTD 的 x 和 y 坐标
        fdtd.setnamed("FDTD", "x min",  Co_Si_FDTD_X_min)
        fdtd.setnamed("FDTD", "x max",  Co_Si_FDTD_X_max)
        fdtd.setnamed("FDTD", "y min",  Co_Si_FDTD_Y_min)
        fdtd.setnamed("FDTD", "y max",  Co_Si_FDTD_Y_max)

        # 设置 trans_box 的 x span 和 y span
        fdtd.setnamed("trans_box", "x span", x_span)
        fdtd.setnamed("trans_box", "y span", y_span)
        
        #设置Al，W的结构参数
        for i in range(5):
            for j in range(5):
                Al_W_1_X_min = x0-c-(T_x//2+(T_x%2)/2-i)*(l+b+2*c)
                Al_W_1_X_max = x0+c-(T_x//2+(T_x%2)/2-i)*(l+b+2*c)
                Al_W_1_Y_min = y0-(w/2 + d/2)+(T_y//2+(T_y%2)/2-j)*(d+w)
                Al_W_1_Y_max = y0+(w/2 + d/2)+(T_y//2+(T_y%2)/2-j)*(d+w)

                Al_W_2_X_min = x0-(l/2+c)-(T_x//2+(T_x%2)/2-i)*(l+b+2*c)
                Al_W_2_X_max = x0+(l/2+c)-(T_x//2+(T_x%2)/2-i)*(l+b+2*c)
                Al_W_2_Y_min = y0-w/2+(T_y//2+(T_y%2)/2-j)*(d+w)
                Al_W_2_Y_max = y0+w/2+(T_y//2+(T_y%2)/2-j)*(d+w)

                # # 计算结构的名称
                # structure_name = f'Al_{i}_{j}_1'
                # # 设置结构
                # fdtd.addrect()
                # fdtd.set('name', structure_name)
                # fdtd.set('x min', Al_W_X_min)
                # fdtd.set('x max', Al_W_X_max)
                # fdtd.set('y min', Al_W_Y_min)
                # fdtd.set('y max', Al_W_Y_max)
                # fdtd.set('z min', 0)
                # fdtd.set('z max', 0.465)
                # fdtd.set('material', 'Al (Aluminium) - CRC')  # 设置材料为 Al
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_1", "x min", Al_W_1_X_min)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_1", "x max", Al_W_1_X_max)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_1", "y min", Al_W_1_Y_min)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_1", "y max", Al_W_1_Y_max)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_1", "z min", 0)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_1", "z max", 0.465*1e-6)
                # structure_name = f'Al_{i}_{j}_2'
                # # 设置结构
                # fdtd.addrect()
                # fdtd.set('name', structure_name)
                # fdtd.set('x min', Al_W_X_min)
                # fdtd.set('x max', Al_W_X_max)
                # fdtd.set('y min', Al_W_Y_min)
                # fdtd.set('y max', Al_W_Y_max)
                # fdtd.set('z min', 0)
                # fdtd.set('z max', 0.465)
                # fdtd.set('material', 'Al (Aluminium) - CRC')  # 设置材料为 Al
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_2", "x min", Al_W_2_X_min)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_2", "x max", Al_W_2_X_max)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_2", "y min", Al_W_2_Y_min)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_2", "y max", Al_W_2_Y_max)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_2", "z min", 0)
                fdtd.setnamed("Al_"+str(i)+"_"+str(j)+"_2", "z max", 0.465*1e-6)
                # structure_name = f'W_{i}_{j}_1'
                # # 设置结构
                # fdtd.addrect()
                # fdtd.set('name', structure_name)
                # fdtd.set('x min', Al_W_X_min)
                # fdtd.set('x max', Al_W_X_max)
                # fdtd.set('y min', Al_W_Y_min)
                # fdtd.set('y max', Al_W_Y_max)
                # fdtd.set('z min', -0.65)
                # fdtd.set('z max', 0)
                # fdtd.set('material', 'W (Tungsten) - Palik')  # 设置材料为 W
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_1", "x min", Al_W_1_X_min)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_1", "x max", Al_W_1_X_max)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_1", "y min", Al_W_1_Y_min)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_1", "y max", Al_W_1_Y_max)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_1", "z min", -0.64*1e-6)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_1", "z max", 0)
                # structure_name = f'W_{i}_{j}_2'
                # # 设置结构
                # fdtd.addrect()
                # fdtd.set('name', structure_name)
                # fdtd.set('x min', Al_W_X_min)
                # fdtd.set('x max', Al_W_X_max)
                # fdtd.set('y min', Al_W_Y_min)
                # fdtd.set('y max', Al_W_Y_max)
                # fdtd.set('z min', -0.65)
                # fdtd.set('z max', 0)
                # fdtd.set('material', 'W (Tungsten) - Palik')  # 设置材料为 W
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_2", "x min", Al_W_2_X_min)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_2", "x max", Al_W_2_X_max)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_2", "y min", Al_W_2_Y_min)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_2", "y max", Al_W_2_Y_max)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_2", "z min", -0.64*1e-6)
                fdtd.setnamed("W_"+str(i)+"_"+str(j)+"_2", "z max", 0)
                # #材料表里面没有找到Co，选择在FDTD里面建立一个模型用setname的方法来替代
                # # structure_name = f'Co'
                # # # 设置结构
                # # fdtd.addrect()
                # # fdtd.set('name', structure_name)
                # # fdtd.set('x min', Co_Si_FDTD_X_min)
                # # fdtd.set('x max', Co_Si_FDTD_X_max)
                # # fdtd.set('y min', Co_Si_FDTD_Y_min)
                # # fdtd.set('y max', Co_Si_FDTD_Y_max)
                # # fdtd.set('z min', -0.67)
                # # fdtd.set('z max', -0.65)
                # # fdtd.set('material', 'Co (Cobalt)')  # 设置材料为 Co
                # 设置 W_1 的 x 和 y 坐标，基于图片中的公式
                fdtd.setnamed("Co", "x min", Co_Si_FDTD_X_min)
                fdtd.setnamed("Co", "x max", Co_Si_FDTD_X_max)
                fdtd.setnamed("Co", "y min", Co_Si_FDTD_Y_min)
                fdtd.setnamed("Co", "y max", Co_Si_FDTD_Y_max)
                fdtd.setnamed("Co", "z min", -0.67*1e-6)
                fdtd.setnamed("Co", "z max", -0.65*1e-6)
                
                # structure_name = f'Si'
                # # 设置结构
                # fdtd.addrect()
                # fdtd.set('name', structure_name)
                # fdtd.set('x min', Co_Si_FDTD_X_min)
                # fdtd.set('x max', Co_Si_FDTD_X_max)
                # fdtd.set('y min', Co_Si_FDTD_Y_min)
                # fdtd.set('y max', Co_Si_FDTD_Y_max)
                # fdtd.set('z min', -3*1e-6)
                # fdtd.set('z max', -0.67*1e-6)
                # fdtd.set('material', 'Si (Silicon) - Palik')  # 设置材料为 Si
                fdtd.setnamed("Si", "x min", Co_Si_FDTD_X_min)
                fdtd.setnamed("Si", "x max", Co_Si_FDTD_X_max)
                fdtd.setnamed("Si", "y min", Co_Si_FDTD_Y_min)
                fdtd.setnamed("Si", "y max", Co_Si_FDTD_Y_max)
                fdtd.setnamed("Si", "z min", -3*1e-6)
                fdtd.setnamed("Si", "z max", -0.67*1e-6)
            
        # 运行仿真
        fdtd.run()

        # 获取监视器R的可视化数据
        visualize_data = fdtd.getresult("R", "T")

        # 提取波长和透射率数据
        lambda_data = visualize_data['lambda']
        T_data = visualize_data['T']

        A_data = 1 - T_data

        # 将数据转换为DataFrame
        df_result = pd.DataFrame({'Wavelength (nm)': lambda_data.flatten() * 1e9, 'Absorptivity': A_data})

        # 保存结果DataFrame到CSV文件
        # 使用唯一标识符命名结果文件
        result_filename = f'{save_path}absorptivity_c_{index}.csv'
        df_result.to_csv(result_filename, index=False)

        # 计算平均吸收率
        absorptivity = calculate_average_absorptivity(result_filename, 1450, 1650)

        #创建一个列表保存结构参数
        structure_parameters =  [[0]*1]*epoches
        structure_parameters[t] = [c,l,w,d,b,T_x,T_y]
        t = t+1
# 关闭FDTD仿真会话
    fdtd.save()
    fdtd.close()

#将初始化粒子的结构参数和吸收率保存到CSV文件中
df_result = pd.DataFrame({'structure_parameters': structure_parameters *1e6, 'Absorptivity': absorptivity})
result_filename = f'{save_path}dataset.csv'
df_result.to_csv(result_filename, index=False)